create
    definer = root@localhost procedure getBookById(IN id int)
begin
    SELECT b.id,
           b.categoryId,
           b.name,
           b.price,
           b.stock,
           b.totalPages,
           b.yearCreated,
           b.author,
           c.name as categoryName,
           b.status
    FROM book b
             INNER JOIN category c ON b.categoryId = c.id
    WHERE b.id = id;
end;

