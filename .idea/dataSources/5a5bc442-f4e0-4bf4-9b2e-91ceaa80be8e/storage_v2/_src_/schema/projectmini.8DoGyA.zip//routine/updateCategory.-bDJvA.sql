create
    definer = root@localhost procedure updateCategory(IN id int, IN newName varchar(255))
begin
    UPDATE category SET name = newName WHERE id = id;
end;

