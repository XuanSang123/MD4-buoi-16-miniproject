create
    definer = root@localhost procedure listBook()
begin
    SELECT b.id,
           b.name,
           b.price,
           b.stock,
           b.totalPages,
           b.yearCreated,
           b.author,
           c.name as categoryName,
           b.status
    FROM book b
             INNER JOIN category c ON b.categoryId = c.id;
end;

