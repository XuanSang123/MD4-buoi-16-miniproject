create
    definer = root@localhost procedure listCategories()
begin
    SELECT * FROM category;
end;

