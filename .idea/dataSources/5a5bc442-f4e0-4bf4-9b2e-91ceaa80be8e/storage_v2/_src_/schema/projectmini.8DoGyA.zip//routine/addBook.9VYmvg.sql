create
    definer = root@localhost procedure addBook(IN categoryId int, IN newName varchar(255), IN price double,
                                               IN stock int, IN totalPages int, IN yearCreated int,
                                               IN author varchar(255), IN status tinyint(1))
begin
    INSERT INTO book (categoryId, name, price, stock, totalPages, yearCreated, author, status)
    VALUES (categoryId, newName, price, stock, totalPages, yearCreated, author, status);
end;

