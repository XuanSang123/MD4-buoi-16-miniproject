create
    definer = root@localhost procedure deleteBook(IN id int)
begin
    DELETE FROM book WHERE id = id;
END;

