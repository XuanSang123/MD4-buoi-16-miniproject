create
    definer = root@localhost procedure deleteCategory(IN id int)
begin
    DELETE FROM category WHERE id = id;
END;

