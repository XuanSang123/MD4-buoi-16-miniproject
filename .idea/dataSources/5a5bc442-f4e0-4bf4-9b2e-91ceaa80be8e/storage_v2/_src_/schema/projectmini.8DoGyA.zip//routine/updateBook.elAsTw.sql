create
    definer = root@localhost procedure updateBook(IN id int, IN categoryId int, IN newName varchar(255),
                                                  IN price double, IN stock int, IN totalPages int, IN yearCreated int,
                                                  IN author varchar(255), IN status tinyint(1))
begin
    UPDATE book
    SET categoryId  = categoryId,
        name        = newName,
        price       = price,
        stock       = stock,
        totalPages  = totalPages,
        yearCreated = yearCreated,
        author      = author,
        status      = status
    WHERE id = id;
end;

