create
    definer = root@localhost procedure addCategory(IN newName varchar(255))
begin
    INSERT INTO category (name) VALUES (newName);
end;

