create
    definer = root@localhost procedure getBooksByCategoryId(IN categoryId int)
begin
    SELECT b.id,
           b.categoryId,
           b.name,
           b.price,
           b.stock,
           b.totalPages,
           b.yearCreated,
           b.author,
           c.name as categoryName,
           b.status
    FROM book b
             INNER JOIN category c ON b.categoryId = c.id
    WHERE b.categoryId = categoryId;
end;

